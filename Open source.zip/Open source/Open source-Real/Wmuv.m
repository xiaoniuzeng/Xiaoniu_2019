function W= Wmuv(s, M, N)
% Wmuv Generate wavenumber matrix.
%  IN      S:   	 sampling interval
%           M,N:   Number of points and lines of data
%
%  OUT  W:  	output wavenumber matrix

% Set up range of variables.
u=0:(1/(M*s)):(1/s-1/(M*s)); 
v=0:(1/(N*s)):(1/s-1/(N*s)); 
% Compute the indices for use in meshgrid.
idx = find(u>1/(2*s));
u(idx) = u(idx) - 1/s;
idy = find(v>1/(2*s));
v(idy) = v(idy) - 1/s;
% Compute the meshgrid arrays.
[V, U] = meshgrid(v, u);
% Generate wavenumber matrix
W=sqrt(U.^2+V.^2);
end

