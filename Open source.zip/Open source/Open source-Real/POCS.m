tic
clc;clear;
load AM_A.mat        %aeromagnetic data from Afghanistan show in Fig. 7a
load AM_I_N.mat     %noisy aeromagnetic data show in Fig. 7b
load M.mat               %sampling operator; 1 for the known data and 0 for the unknown data
%% %
s=1000;                                                              %sampling interval
w_1=1/(s*max(size(AM_A,1),size(AM_A,2))); %fundamental wavenumber
w_N=0.00013;                                                  %maximum cutoff wavenumber;determin by using fractal model
N=100;                                                             %the maximum iteration number
w=linspace(w_1,w_N,N);                                 %the cutoff wavenumber set
W1=Wmuv(s,size(AM_A,1),size(AM_A,2));     %wavenumber matrix
I_D=sum(M(:));                                                 %the number of data used to calculate the denoising RMSEs.
G_n=AM_I_N;                                                   %iteration initial value
for n=1:N
      T_n=double(W1< w(n));                                                     %the threshold operator
      G_n=real(ifft2(T_n.*fft2(AM_I_N+(1-M).*G_n)));                %iteration process
      RMSE_D(n)=sqrt(sum(sum(M.*   (G_n-AM_A).^2))/I_D);   %denoising RMSEs
end
toc
F_RMSEs=RMSE_D(N);                                      %the final RMSEs of the denoising




