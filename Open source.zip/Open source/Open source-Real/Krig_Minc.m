clc;clear;
load AM_A.mat       %aeromagnetic data from Afghanistan show in Fig. 7a
load R_Krig.mat      %reconstruction result by using the kriging method (VM=Exponential)
load R_Minc.mat     %reconstruction result by using the minimum curvature method (MR=0.001)
load M.mat             %sampling operator; 1 for the known data and 0 for the unknown data

%% denoising by using the wavelet decomposition method
[Thr_K,Sorh_K,Keepapp_K]=ddencmp('den','wv',R_Krig); 
Krig_W=wdencmp('gbl',R_Krig,'sym10',3,Thr_K,Sorh_K,Keepapp_K);   
[Thr_M,Sorh_M,Keepapp_M]=ddencmp('den','wv',R_Minc);
Minc_W=wdencmp('gbl',R_Minc,'sym10',3,Thr_M,Sorh_M,Keepapp_M);   
%% calculate the denoising RMSEs
I_D=sum(M(:));      %the number of data used to calculate the denoising RMSEs.
RMSE_Krig_D=sqrt(sum(sum(M.*(Krig_W- AM_A).^2  ))/I_D);
RMSE_Minc_D=sqrt(sum(sum(M.*(Minc_W- AM_A).^2  ))/I_D);
