tic
clc;clear;
load G_P.mat        %actual gravity data of the model show in Figure 4b
load G_I_N.mat     %incomplete noisy gravity data show in Figure 4d
load M.mat           %sampling operator; 1 for the known data and 0 for the unknown data
load M_I.mat        %sampling operator for calculate the interplation RMSEs;
load M_B.mat       %sampling operator for calculate the border-padding RMSEs;
%% %
s=50;                                                        %sampling interval
w_1=1/(s*max(size(G_P,1),size(G_P,2))); %fundamental wavenumber
w_N=0.001;                                              %maximum cutoff wavenumber;determin by using fractal model
N=1000;                                                    %maximum iteration number
w=linspace(w_1,w_N,N);                         %cutoff wavenumber set
WM=Wmuv(s,size(G_P,1),size(G_P,2));    %wavenumber matrix
I_I=sum(M_I(:));                                        %number of data used to calculate the interpolation RMSEs.
I_B=sum(M_B(:));                                      %number of data used to calculate the border-padding RMSEs.
I_D=sum(M(:));                                         %number of data used to calculate the denoising RMSEs.
G_n=G_I_N;                                              %iteration initial value
for n=1:N
      T_n=double(WM< w(n));                                                %threshold operator
      G_n=real(ifft2(T_n.*fft2(G_I_N+(1-M).*G_n)));               %iteration process
      RMSE_I(n) =sqrt(sum(sum(M_I.* (G_n-G_P).^2))/I_I );   %interplation RMSEs
      RMSE_B(n)=sqrt(sum(sum(M_B.*(G_n-G_P).^2))/I_B);   %border-padding RMSEs
      RMSE_D(n)=sqrt(sum(sum(M.*   (G_n-G_P).^2))/I_D);   %denoising RMSEs
end
toc
F_RMSEs=[RMSE_I(N) RMSE_B(N) RMSE_D(N)]; %the final RMSEs of the interpolation, border-padding and denoising




