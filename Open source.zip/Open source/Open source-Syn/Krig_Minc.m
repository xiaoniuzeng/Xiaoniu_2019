clc;clear;
load G_P.mat          %actual gravity data of the model show in Figure 4a
load R_Krig.mat      %reconstruction result by using the kriging method (VM=Linear)
load R_Minc.mat     %reconstruction result by using the minimum curvature method (MR=0.0001)
load M.mat             %sampling operator; 1 for the known data and 0 for the unknown data
load M_I.mat           %sampling operator for calculate the interplation RMSEs;
load M_B.mat          %sampling operator for calculate the border-padding RMSEs;

%% denoising by using the wavelet decomposition method
[Thr_K,Sorh_K,Keepapp_K]=ddencmp('den','wv',R_Krig); 
Krig_W=wdencmp('gbl',R_Krig,'sym8',3,Thr_K,Sorh_K,Keepapp_K);   
[Thr_M,Sorh_M,Keepapp_M]=ddencmp('den','wv',R_Minc);
Minc_W=wdencmp('gbl',R_Minc,'sym8',3,Thr_M,Sorh_M,Keepapp_M);   
%% calculate the interplation RMSEs
I_I=sum(M_I(:));    %number of data used to calculate the interpolation RMSEs.
RMSE_Krig_I=sqrt(sum(sum(M_I.*(Krig_W-G_P).^2  ))/I_I);
RMSE_Minc_I=sqrt(sum(sum(M_I.*(Minc_W-G_P).^2  ))/I_I);
%% calculate the border-padding RMSEs
I_B=sum(M_B(:));  %number of data used to calculate the border-padding RMSEs.
RMSE_Krig_B=sqrt(sum(sum(M_B.*(Krig_W-G_P).^2  ))/I_B );
RMSE_Minc_B=sqrt(sum(sum(M_B.*(Minc_W-G_P).^2  ))/I_B );
%% calculate the denoising RMSEs
I_D=sum(M(:));      %number of data used to calculate the denoising RMSEs.
RMSE_Krig_D=sqrt(sum(sum(M.*(Krig_W-G_P).^2  ))/I_D);
RMSE_Minc_D=sqrt(sum(sum(M.*(Minc_W-G_P).^2  ))/I_D);
